
## ✅ Final Conclusion

### 🔍 Model Evaluation Summary

| Model               | Accuracy | Precision | Recall  | F1 Score |
|---------------------|----------|-----------|---------|----------|
| **Gradient Boosting** | 0.840    | 0.428     | 0.472   | **0.449** |
| Logistic Regression | 0.731    | 0.310     | **0.775** | 0.443    |
| Naive Bayes         | 0.724    | 0.295     | 0.719   | 0.418    |
| Random Forest       | **0.850**| **0.434** | 0.286   | 0.345    |
| Decision Tree       | 0.796    | 0.292     | 0.334   | 0.312    |

### ✅ Key Insights

- **Gradient Boosting** is the most effective model, achieving the best F1 Score (0.449), which balances both precision and recall.
- **Logistic Regression** yields the **highest recall (0.775)**, making it suitable when it's more important to **catch diabetic cases**, even at the cost of false positives.
- **Random Forest** has the **highest accuracy (0.85)** but a very **low recall**, which makes it risky for medical use cases where false negatives (missed diabetics) are critical.
- **Naive Bayes** and **Decision Tree** perform moderately and can be considered as baseline models.

### 📌 Final Statement

> Based on our evaluation, **Gradient Boosting** stands out as the most balanced model. However, if early detection (high recall) is the top priority in a medical setting, **Logistic Regression** is a strong alternative.

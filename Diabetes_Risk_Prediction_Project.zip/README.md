
# 🩺 Diabetes Risk Prediction Using Machine Learning

## 📁 Project Structure

- `Final_Conclusion_Diabetes_Model_Evaluation.md` — Final project conclusion and model evaluation summary.
- `Final_Diabetes_Model_Conclusion.ipynb` — Jupyter Notebook with conclusion cell (ready to be extended with code and analysis).
- `README.md` — This file, explaining the project.

## 📊 Summary

This project explores several machine learning models (Logistic Regression, Random Forest, Decision Tree, Gradient Boosting, Naive Bayes) for predicting diabetes risk. After evaluating them on accuracy, precision, recall, and F1 score, Gradient Boosting proved to be the most balanced model.

## ✅ How to Use

1. Open the `.ipynb` notebook in Jupyter.
2. Extend the notebook by adding EDA, model training, evaluation, and the final conclusion cell (already included).
3. Use the `.md` file for reports or GitHub documentation.

## 📌 Author

Prepared by Ashik
